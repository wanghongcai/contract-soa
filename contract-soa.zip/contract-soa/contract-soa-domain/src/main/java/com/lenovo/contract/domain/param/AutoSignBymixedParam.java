package com.lenovo.contract.domain.param;

import java.io.Serializable;

/**
 * Created by xuweihua on 2017/3/1.
 */
public class AutoSignBymixedParam  implements Serializable {
    private String orderId;
    private String devno;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getDevno() {
        return devno;
    }

    public void setDevno(String devno) {
        this.devno = devno;
    }
}
