package com.lenovo.contract.domain.param;

import com.lenovo.m2.arch.tool.util.StringUtils;

import java.io.Serializable;

/**
 * Created by xuweihua on 2017/3/1.
 */
public class SendUserParam  implements Serializable {

    private String id;//分销商id
    private String name;
    private String email;
    private String mobile;
    private Integer usertype;
    private String mid;//分销商mid 上上签提供
    private String privatekey;//分销商key 上上签提供

    public String getDevno(){
        if (StringUtils.isEmpty(email)){
            return mobile;
        }
        return email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getUsertype() {
        return usertype;
    }

    public void setUsertype(Integer usertype) {
        this.usertype = usertype;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getPrivatekey() {
        return privatekey;
    }

    public void setPrivatekey(String privatekey) {
        this.privatekey = privatekey;
    }
}
