package com.lenovo.contract.domain.result;

import java.io.Serializable;

/**
 * Created by xuweihua on 2017/3/3.
 */
public class SignResultResult implements Serializable {
    private int code = 0;
    private String docid = "";
    private String filecode = "";
    private String vmsg = "";
    private Boolean signend = Boolean.valueOf(false);
    private String status = "";
    private String endtime;
    private String signdate;
    private String fmid;

    public String getFmid() {
        return this.fmid;
    }

    public void setFmid(String fmid) {
        this.fmid = fmid;
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDocid() {
        return this.docid;
    }

    public void setDocid(String docid) {
        this.docid = docid;
    }

    public String getFilecode() {
        return this.filecode;
    }

    public void setFilecode(String filecode) {
        this.filecode = filecode;
    }

    public String getVmsg() {
        return this.vmsg;
    }

    public void setVmsg(String vmsg) {
        this.vmsg = vmsg;
    }

    public Boolean getSignend() {
        return this.signend;
    }

    public void setSignend(Boolean signend) {
        this.signend = signend;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getEndtime() {
        return this.endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getSigndate() {
        return this.signdate;
    }

    public void setSigndate(String signdate) {
        this.signdate = signdate;
    }
}
