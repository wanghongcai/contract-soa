package com.lenovo.contract.domain;

import java.io.Serializable;

public class Contract  implements Serializable {

    private String contractId;
    private String docId;
    private String sendUserDevno;
    private String receiveUserDevno;
    private String sendUserId;
    private String receiveUserId;
    private String docSurl;
    private String docQurl;

    private String orderId;

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getSendUserId() {
        return sendUserId;
    }

    public void setSendUserId(String sendUserId) {
        this.sendUserId = sendUserId;
    }

    public String getReceiveUserId() {
        return receiveUserId;
    }

    public void setReceiveUserId(String receiveUserId) {
        this.receiveUserId = receiveUserId;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getSendUserDevno() {
        return sendUserDevno;
    }

    public void setSendUserDevno(String sendUserDevno) {
        this.sendUserDevno = sendUserDevno;
    }

    public String getReceiveUserDevno() {
        return receiveUserDevno;
    }

    public void setReceiveUserDevno(String receiveUserDevno) {
        this.receiveUserDevno = receiveUserDevno;
    }

    public String getDocSurl() {
        return docSurl;
    }

    public void setDocSurl(String docSurl) {
        this.docSurl = docSurl;
    }

    public String getDocQurl() {
        return docQurl;
    }

    public void setDocQurl(String docQurl) {
        this.docQurl = docQurl;
    }
}