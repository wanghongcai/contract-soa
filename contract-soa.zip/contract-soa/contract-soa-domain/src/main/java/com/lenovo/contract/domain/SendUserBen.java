package com.lenovo.contract.domain;

import java.io.Serializable;

/**
 * Created by xuweihua on 2017/2/28.
 */
public class SendUserBen implements Serializable {
    private String name;
    private String email;
    private String mobile;
    private Integer usertype;
    private Integer selfsign;
    private String idcode;
    private String address;
    private String linkman;
    private String cacerid;
    private String taxcode;
    private String orgcode;
    private Boolean autoSign;
    private int signPage;
    private Float signPageX;
    private Float signPageY;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype =Integer.parseInt(usertype);
    }

    public Integer getSelfsign() {
        return selfsign;
    }

    public void setSelfsign(String selfsign) {
        this.selfsign = Integer.parseInt(selfsign);
    }

    public String getIdcode() {
        return idcode;
    }

    public void setIdcode(String idcode) {
        this.idcode = idcode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLinkman() {
        return linkman;
    }

    public void setLinkman(String linkman) {
        this.linkman = linkman;
    }

    public String getCacerid() {
        return cacerid;
    }

    public void setCacerid(String cacerid) {
        this.cacerid = cacerid;
    }

    public String getTaxcode() {
        return taxcode;
    }

    public void setTaxcode(String taxcode) {
        this.taxcode = taxcode;
    }

    public String getOrgcode() {
        return orgcode;
    }

    public void setOrgcode(String orgcode) {
        this.orgcode = orgcode;
    }

    public Boolean getAutoSign() {
        return autoSign;
    }

    public void setAutoSign(String autoSign) {
        this.autoSign = Boolean.parseBoolean(autoSign);
    }

    public int getSignPage() {
        return signPage;
    }

    public void setSignPage(String signPage) {
        this.signPage = Integer.parseInt(signPage);
    }

    public Float getSignPageX() {
        return signPageX;
    }

    public void setSignPageX(String signPageX) {
        this.signPageX = Float.parseFloat(signPageX);
    }

    public Float getSignPageY() {
        return signPageY;
    }

    public void setSignPageY(String signPageY) {
        this.signPageY = Float.parseFloat(signPageY);
    }
}
