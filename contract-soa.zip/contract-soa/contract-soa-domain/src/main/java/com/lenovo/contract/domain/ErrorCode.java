package com.lenovo.contract.domain;

/**
 * Created by xuweihua on 2017/5/8.
 */
public class ErrorCode {
    public final static String SUCCESSFUL="0000";//成功
    public final static String FAILURE="9999";//系统异常
    public final static String PARAMETER_ERROR="1000";//参数不能为空
    public final static String SSQ_FAILURE="1001";//调用上上签系统异常

}
