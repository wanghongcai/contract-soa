package com.lenovo.contract.api;

import com.lenovo.contract.domain.Contract;
import com.lenovo.contract.domain.param.AutoSignBymixedParam;
import com.lenovo.contract.domain.param.GenerateContractParam;
import com.lenovo.contract.domain.param.ReceiveUserParam;
import com.lenovo.contract.domain.param.SendUserParam;
import com.lenovo.contract.domain.result.SignResultResult;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;

import java.util.Map;


public interface ContractApiService {

    RemoteResult generateContract(GenerateContractParam generateContractParam,Tenant tenant);

    RemoteResult generateContractRealTime(GenerateContractParam generateContractParam,Tenant tenant);

    RemoteResult<String> createReceiveUserAndcertApply(ReceiveUserParam receiveUser);

    RemoteResult<String> createSendUserAndcertApply(SendUserParam sendUser);

    RemoteResult<String> autoSignBymixed(AutoSignBymixedParam autoSignBymixedParam,Tenant tenant);

    RemoteResult<Contract> getContract(String orderId);

}
