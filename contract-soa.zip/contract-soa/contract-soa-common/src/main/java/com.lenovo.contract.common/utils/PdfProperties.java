package com.lenovo.contract.common.utils;

/**
 * Created by xuweihua on 2017/3/1.
 */
public class PdfProperties {
    private String htmlPath;
    private String pdfPath;
    private String htmlUrl;
    private String accessUrl;

    private String sendUserX;
    private String sendUserY;
    private String receiveUserX;
    private String receiveUserY;

    public String getSendUserX() {
        return sendUserX;
    }

    public void setSendUserX(String sendUserX) {
        this.sendUserX = sendUserX;
    }

    public String getSendUserY() {
        return sendUserY;
    }

    public void setSendUserY(String sendUserY) {
        this.sendUserY = sendUserY;
    }

    public String getReceiveUserX() {
        return receiveUserX;
    }

    public void setReceiveUserX(String receiveUserX) {
        this.receiveUserX = receiveUserX;
    }

    public String getReceiveUserY() {
        return receiveUserY;
    }

    public void setReceiveUserY(String receiveUserY) {
        this.receiveUserY = receiveUserY;
    }

    public String getAccessUrl() {
        return accessUrl;
    }

    public void setAccessUrl(String accessUrl) {
        this.accessUrl = accessUrl;
    }

    public String getHtmlPath() {
        return htmlPath;
    }

    public void setHtmlPath(String htmlPath) {
        this.htmlPath = htmlPath;
    }

    public String getPdfPath() {
        return pdfPath;
    }

    public void setPdfPath(String pdfPath) {
        this.pdfPath = pdfPath;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }

    public void setHtmlUrl(String htmlUrl) {
        this.htmlUrl = htmlUrl;
    }
}
