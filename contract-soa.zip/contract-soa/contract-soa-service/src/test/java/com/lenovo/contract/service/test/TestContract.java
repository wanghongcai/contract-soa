package com.lenovo.contract.service.test;

import com.lenovo.contract.api.ContractApiService;
import com.lenovo.contract.common.utils.JacksonUtil;
import com.lenovo.contract.common.utils.JsonUtil;
import com.lenovo.contract.domain.param.GenerateContractParam;
import com.lenovo.contract.domain.param.ReceiveUserParam;
import com.lenovo.contract.domain.param.SendUserParam;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by xuweihua on 2017/3/1.
 */
public class TestContract extends BaseServiceTestCase {

    @Autowired
    private ContractApiService contractApiService;

    @Test
    public void test(){
        GenerateContractParam generateContractParam=new GenerateContractParam();
        generateContractParam.setSendUserID("0100008723");
        generateContractParam.setReceiveUserID("1000076363");
        generateContractParam.setMoney("6000.0");
        generateContractParam.setSendUserName("测试发送用户");
        generateContractParam.setReceiveUserName("测试接收用户");
        generateContractParam.setOrderId("1524887078763");

        Tenant tenant=new Tenant();
        tenant.setShopId(14);
        tenant.setCurrencyCode("CNY");

        RemoteResult<String> result= contractApiService.generateContract(generateContractParam, tenant);
        System.out.println(result.getT());

    }

    @Test
    public void testCreateReceiveUserAndcertApply(){
        ReceiveUserParam receiveUser= new ReceiveUserParam();
        receiveUser.setAddress("淄博市张店北西六路15号");
        receiveUser.setName("淄博世纪鑫海科贸有限公司");
        receiveUser.setId("1000055247");
        receiveUser.setMobile("13573312797");
        receiveUser.setUserType(2);
        receiveUser.setMid("feee559e9e5e4818b6ab28283fa62666");
        receiveUser.setPrivatekey("MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAINaoiE05a4QAlLTr+th5lPs4xTozbK+5nZ3oRHusNdTJvsIACwnmfGIru154O0rSNst6jmsTTyVZq0mOktmdX1MtKFiXTUaxfmlVJvdkM/R4M5yeW8HLiwyTJcImbqEOP1c4NH6AFhSWrjueY3G3w0bi6MOBoRR3khyGcXR7NJrAgMBAAECgYAmmSlvTJX5cibco+vb5SbDnqaT7F0Vm1cplLm2BUfd3kdkGNPEJdbszNdqXRglWUTNc06Sp/kCRnyngMY8hd0cCnYRckrt6VRm0GCBJJ/a50gTjSDWm4BNLTTq6j2DsKPNJ562mHn7Pt3H1lm24N22HagPXDOqXwknZyVqIDRqIQJBAMpEqvXz65RyMXjx5a94+utrEh3STCTgS947wWKf40M1nTC0GbeZ2kHeqoQuOk+/VcGrze3V0s4uF3G7GMeecmkCQQCmP2rJgv5VxsQYZtbCibveC6vv/eQb7mwZcQyIpT51yzpf3D1w8gV1Ga1tK+lFjyBm89aqDavsBPgusvARy9uzAkAWlrqdAyOhDWu2/RTQlus21VtNl0nHqIDwja3YLND9lYQ7hzGEDpuQVaSnZF5Av7Z9DYnO8N09B2q42dM3n9tZAkAXki5F2/jLmJ79Bre0ZWrplKYQJONOwoM5KDoqtaMheGsSZFuhw+7aJ4XbULqGTkC92By7h6y0jg/SLzSykUDZAkAcPD4xMPx3c4+1iV9GZi0m9gq7dEbCbMP55B4RlvCANgcDB2AWV/+mt+mw7PpTxfpyqV1e9DQpmmtcOEmP6Ru1");
        receiveUser.setLinkMan("魏秀玲");
        receiveUser.setProvince("山东省");
        receiveUser.setCity("淄博市");
        receiveUser.setLinkIdCode("370302197109235423");
        receiveUser.setIcCode("91370303744513925Y");
        receiveUser.setOrgCode("91370303744513925Y");
        receiveUser.setTaxCode("91370303744513925Y");
        RemoteResult<String> result= contractApiService.createReceiveUserAndcertApply(receiveUser);
        System.out.println(JacksonUtil.toJson(result));

    }

}
