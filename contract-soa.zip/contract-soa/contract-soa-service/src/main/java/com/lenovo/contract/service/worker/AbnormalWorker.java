package com.lenovo.contract.service.worker;

import com.lenovo.contract.api.ContractApiService;
import com.lenovo.contract.common.utils.JacksonUtil;
import com.lenovo.contract.dao.ContractMapper;
import com.lenovo.contract.domain.AbnormalLog;
import com.lenovo.contract.domain.param.GenerateContractParam;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.context.ServletContextAware;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.ServletContext;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by xuweihua on 2017/3/15.
 */

public class AbnormalWorker{
    private static final Logger logger = LoggerFactory.getLogger("com.lenovo.contract.service.impl.contract");

    private static ScheduledExecutorService service = Executors.newScheduledThreadPool(1);

    @Autowired
    private ContractMapper contractMapper;
    @Autowired
    private ContractApiService contractApiService;

    @PostConstruct
    public void init(){
        service.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                try {
                    ArrayList<AbnormalLog> abnormalLogs= contractMapper.getAbnormalLog();
                    for (int i=0;abnormalLogs.size()>i;i++){
                        GenerateContractParam generateContractParam=new GenerateContractParam();
                        BeanUtils.copyProperties(generateContractParam,abnormalLogs.get(i));
                        RemoteResult remoteResult=contractApiService.generateContract(generateContractParam, JacksonUtil.fromJson(abnormalLogs.get(i).getTenant(),Tenant.class));
                        if (remoteResult.isSuccess()){
                            contractMapper.updateAbnormalLog(generateContractParam.getOrderId());
                        }
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                }
            }
        }, 1, 1, TimeUnit.MINUTES);
    }
}
