package com.lenovo.contract.service.impl.tes;

import com.lenovo.m2.arch.tool.util.StringUtils;

import java.io.Serializable;

/**
 * Created by xuweihua on 2017/3/1.
 */
public class ReceiveUserParam implements Serializable {
    private String mid;//绑定的分销商mid 上上签提供
    private String privatekey;//分销商key 上上签提供
    private String id;//经销商id
    private String name;
    private String email;
    private String mobile;
    private Integer userType;
    private String linkMan;//联系人姓名,联系人姓名(企业用户必填)
    private String linkIdCode;//	身份证号	Y	18	身份证号
    private String icCode;//工商注册号	Y		注册号(企业用户必填)，如果为三证合一，填统一社会信用代码
    private String orgCode;//	组织机构代码	Y		组织机构代码(企业用户必填) ，如果为三证合一，填统一社会信用代码
    private String taxCode;//	税务登记证号	Y		税务登记证号(企业用户必填) ，如果为三证合一，填统一社会信用代码
    private String province;//省份	Y	10	省份
    private String city;//城市	Y	10	城市
    private String address;//	地址	Y	50	企业具体地址

    private String devno;

    public String getDevno() {
        return devno;
    }

    public void setDevno(String devno) {
        this.devno = devno;
    }

    public String getLinkIdCode() {
        return linkIdCode;
    }

    public void setLinkIdCode(String linkIdCode) {
        this.linkIdCode = linkIdCode;
    }

    public String getPrivatekey() {
        return privatekey;
    }

    public void setPrivatekey(String privatekey) {
        this.privatekey = privatekey;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan;
    }

    public String getIcCode() {
        return icCode;
    }

    public void setIcCode(String icCode) {
        this.icCode = icCode;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
