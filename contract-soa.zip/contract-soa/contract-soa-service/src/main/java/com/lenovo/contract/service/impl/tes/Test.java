package com.lenovo.contract.service.impl.tes;

import cn.bestsign.sdk.BestSignSDK;
import cn.bestsign.sdk.integration.Constants;
import com.alibaba.fastjson.JSONObject;
import com.lenovo.contract.common.utils.JacksonUtil;
import com.lenovo.contract.domain.param.*;

/**
 * Created by xuweihua on 2017/7/26.
 */
public class Test {
    public static void main(String[] args) {
        BestSignSDK client= null;
        ReceiveUserParam receiveUser= JacksonUtil.fromJson("{\"address\":\"邹平县黛西五路\",\"name\":\"邹平智维信息工程有限公司9\",\"id\":\"1000000776\",\"email\":null,\"mobile\":\"15805430112\",\"userType\":2,\"mid\":\"c9f5742951e745dba733eb372d3150d9\",\"privatekey\":\"MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJqtOwwYwtDEsFaq5KPMJXd06kyjY1GYx7X2Lz9232JEBbcv3o2UENdw7jEwRoW0BHoGHdP4GMig/6tf85U2zlVKGnsBoxXAgIvi/f3aKN8TU5m7uJVeh/kFvDnul6Sj7Tc3vealUTwRpJDiu34PH9YE33JQmLvlGUzGwvLchHkBAgMBAAECgYA35S/4YB5OmTVsLFdxhb1oXLyqs0SZ4Q8Sh4NteMSi2xgBqe/P09j+MdYxulNRz8rqWbl/tyElp2CdCpCYtHR9NEfmPJAvrVPFThyXUMOpWJjRlGfEf+V1e22V+CQNt0IuprcvoURSYdo3+/5oAwOY5mQcgi1HArk4GwT1JhXUzQJBAPlssys/x6Z4OWeRLnxKB9a8W3bDZLVNEPdzQp/Rfgh5ZsMKhe5A8OqTkAUJUARfoqZN6tJy92IuycwYTwbu1NcCQQCewRowiLmKv58ysH5/VjVO9w5kVXXCNg9LmG7JlHCSp5ToYpWURMFteP3x9aF17j0vO9rPDvqy+OwnBx+teI3nAkEAsY/3kN9rww+tVhRdsm+FWxJmTorVI9hELtSn5lxdy6yZQlo4dB9ZIrV//oXdp+9pO9kWRVFA2W2TjS70+2uEqwJAG1pyRMKKFZoGuBko8o/MB5sR47/F1nyyDfhpvlnRO7OcOJ4j37QpD8+1Eaec9lDiQe0yOlL+Zy/0oJTdpGoNKQJAZLYCZ8Lof92bPmiYb9HbaqSegtjAv4VtiyD0PPU/81nHB9wUqsxOb8jtx5+iImdIUSEHKXXDMXfAqEBPqmUhDQ==\",\"devno\":\"15805430112\",\"linkMan\":\"曲葆煜\",\"province\":\"山东省\",\"city\":\"滨州市\",\"linkIdCode\":\"372330197601013336\",\"icCode\":\"91371626676847965c\",\"orgCode\":\"91371626676847965c\",\"taxCode\":\"91371626676847965c\"}", ReceiveUserParam.class);
        try {
            client = BestSignSDK.getInstance(receiveUser.getMid(), receiveUser.getPrivatekey(), "https://www.bestsign.cn");
            client.setLogDir(System.getProperty("user.dir"));
            client.setDebugLevel(cn.bestsign.sdk.integration.Logger.DEBUG_LEVEL.INFO);
            JSONObject result = client
                    .regUser(Constants.USER_TYPE.ENTERPRISE.value() == receiveUser.getUserType() ? Constants.USER_TYPE.ENTERPRISE : Constants.USER_TYPE.PERSONAL,
                            receiveUser.getEmail(),
                            receiveUser.getMobile(),
                            receiveUser.getName());

            if (result.getJSONObject("response").getJSONObject("info").getString("code").equals("100000")) {
                Constants.CA_TYPE caType = Constants.CA_TYPE.ZJCA;//个人类型的账号申请CFCA,企业类型的账号申请ZJCA
                JSONObject certificateApplyResult = client
                        .certificateApply(caType, receiveUser.getName(),
                                "123456", receiveUser.getLinkMan(), receiveUser.getMobile(),
                                receiveUser.getEmail(), receiveUser.getAddress(), receiveUser.getProvince(),
                                receiveUser.getCity(), receiveUser.getLinkIdCode(), receiveUser.getIcCode(),
                                receiveUser.getOrgCode(), receiveUser.getTaxCode());

                System.out.println(certificateApplyResult.toString());

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
