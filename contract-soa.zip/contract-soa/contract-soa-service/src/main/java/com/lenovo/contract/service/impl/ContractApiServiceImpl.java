package com.lenovo.contract.service.impl;

import cn.bestsign.sdk.BestSignSDK;
import cn.bestsign.sdk.domain.vo.params.ReceiveUser;
import cn.bestsign.sdk.domain.vo.params.SendUser;
import cn.bestsign.sdk.integration.Constants;
import cn.bestsign.sdk.integration.exceptions.BizException;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.lenovo.contract.api.ContractApiService;
import com.lenovo.contract.common.utils.*;
import com.lenovo.contract.dao.ContractMapper;
import com.lenovo.contract.domain.AbnormalLog;
import com.lenovo.contract.domain.Contract;
import com.lenovo.contract.domain.ErrorCode;
import com.lenovo.contract.domain.param.AutoSignBymixedParam;
import com.lenovo.contract.domain.param.GenerateContractParam;
import com.lenovo.contract.domain.param.ReceiveUserParam;
import com.lenovo.contract.domain.param.SendUserParam;
import com.lenovo.contract.service.BaseService;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.hsbuy.domain.middleware.AuditStatusContractParam;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.Product;
import com.lenovo.m2.hsbuy.middleware.OrderMiddlewareService;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.open.gateway.java.sdk.JavaSDKClient;
import com.lenovo.open.gateway.java.sdk.util.Response;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.map.ListOrderedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;


@Service("contractApiService")
public class ContractApiServiceImpl extends BaseService implements ContractApiService {
    private static final Logger logger = LoggerFactory.getLogger(ContractApiServiceImpl.class);

//    @Autowired
//    private SendUserBen sendUserBen;
    @Autowired
    private SignProperties signProperties;
    @Autowired
    private PdfProperties pdfProperties;

    @Autowired
    private ContractMapper contractMapper;

    @Autowired
    private OrderMiddlewareService orderMiddlewareService;

    @Autowired
    private OpenOrderService openOrderService;

    @Autowired
    private ThreadPoolTaskExecutor generateContractExecutor;

    @Override
    public RemoteResult generateContract(GenerateContractParam generateContractParam,Tenant tenant) {
        RemoteResult remoteResult=new RemoteResult(true);
        final GenerateContractParam generateContract_s=generateContractParam;
        final Tenant tenant_s=tenant;
        generateContractExecutor.execute(new Runnable() {
            @Override
            public void run() {
                generateContractStart(generateContract_s,tenant_s);
            }
        });
        return remoteResult;
    }

    @Override
    public RemoteResult generateContractRealTime(GenerateContractParam generateContractParam, Tenant tenant) {
        logger.info("generateContractRealTime请求>>" + JacksonUtil.toJson(generateContractParam));
        RemoteResult remoteResult=new RemoteResult(false);
        try {
            if(ParamBeanUtils.checkFieldValueNull(generateContractParam)) {
                logger.info("generateContractRealTime 》》参数不能为空！");
                remoteResult.setResultCode("1000");
                remoteResult.setResultMsg("参数不能为空！");
                return remoteResult;
            }
            Contract contractIN=contractMapper.selectContract(generateContractParam.getOrderId());
            if(contractIN!=null) {

                //通知订单
                AuditStatusContractParam auditStatusContractParam=new AuditStatusContractParam();
                auditStatusContractParam.setAuditStatus(1);
                auditStatusContractParam.setOrderId(contractIN.getOrderId());
                auditStatusContractParam.setUrl(contractIN.getDocSurl());
//                logger.info("generateContractRealTime 生成合同通知订单参数》》" + JacksonUtil.toJson(auditStatusContractParam));
//                RemoteResult remoteResult1=orderMiddlewareService.updateAuditStatusByContract(tenant,auditStatusContractParam);
//                logger.info("generateContractRealTime 生成合同通知订单返回》》" + JacksonUtil.toJson(remoteResult1));
                remoteResult.setT(auditStatusContractParam);
                remoteResult.setResultCode("0000");
                remoteResult.setResultMsg("成功！");
                remoteResult.setSuccess(true);
                return remoteResult;
            }
            SendUserParam sendUserParam = getSendUserParam(generateContractParam.getSendUserID());
            ReceiveUserParam receiveUserParam = contractMapper.selectReceiveUser(generateContractParam.getReceiveUserID());
            if(StringUtils.isEmpty(sendUserParam.getName())){
                logger.info("generateContractRealTime 》》没有找到分销商！");
                remoteResult.setResultCode("1001");
                remoteResult.setResultMsg("没有找到分销商！");
                return remoteResult;
            }
            if(StringUtils.isEmpty(receiveUserParam.getName())){
                logger.info("generateContractRealTime 》》没有找到经销商！");
                remoteResult.setResultCode("1002");
                remoteResult.setResultMsg("没有找到经销商！");
                return remoteResult;
            }
            URL url = new URL(pdfProperties.getHtmlUrl());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            InputStream inputStream = conn.getInputStream(); //通过输入流获得网站数据
            byte[] getData = readInputStream(inputStream); //获得网站的二进制数据
            String dataHtml = new String(getData, "UTF-8");

            RemoteResult<MongoOrderDetail> result=openOrderService.getMongoOrderDetail(tenant, generateContractParam.getOrderId());
            logger.info("generateContractRealTime 》》订单接口信息！"+JacksonUtil.toJson(result));
            if(result.getT()==null){
                logger.info("generateContractRealTime 》》没有找到订单信息！");
                remoteResult.setResultCode("1003");
                remoteResult.setResultMsg("没有找到订单信息！");
                return remoteResult;
            }
            SimpleDateFormat formath=new SimpleDateFormat("yyyyMMddHHmmss");
            String contractID="HS"+formath.format(new Date())+"H"+generateContractParam.getOrderId();
            dataHtml = dataHtml.replace("contractID",contractID);//合同编号
            dataHtml = dataHtml.replace("sendUserNmae", generateContractParam.getSendUserName());
            dataHtml = dataHtml.replace("receiveUserName", generateContractParam.getReceiveUserName());
            dataHtml = dataHtml.replace("money", generateContractParam.getMoney());
            dataHtml = dataHtml.replace("costItem", result.getT().getCostItem().getAmount().doubleValue()+result.getT().getTotalTax().getAmount().doubleValue()+"");//订单金额
            dataHtml = dataHtml.replace("products", getTable(result.getT()));

            String DEST = pdfProperties.getPdfPath() + "contract.pdf";

            String HTML = pdfProperties.getHtmlPath() + "contract.html";
            File fileHTML = new File(HTML);
            FileWriter fileWritter = new FileWriter(fileHTML);
            BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
            bufferWritter.write(dataHtml);
            bufferWritter.close();
            String cmdret = CmdUtil.callCmd("wkhtmltopdf --margin-bottom 0 --margin-top 0 " + HTML + " " + DEST);
            logger.info("downloadContractFoId----" + "wkhtmltopdf " + HTML + " " + DEST + ">>命令返回：" + cmdret);


            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

            SendUser sendUser = new SendUser(sendUserParam.getEmail(), sendUserParam.getName(), sendUserParam.getMobile(),
                    99, true, Constants.USER_TYPE.ENTERPRISE.value() == sendUserParam.getUsertype() ? Constants.USER_TYPE.ENTERPRISE : Constants.USER_TYPE.PERSONAL,
                    true, sendUserParam.getName() + "-" + receiveUserParam.getName() + "合同" + format.format(new Date()), "");

            ReceiveUser ReceiveUser = new ReceiveUser(receiveUserParam.getEmail(), receiveUserParam.getName(), receiveUserParam.getMobile(),
                    Constants.USER_TYPE.ENTERPRISE.value() == receiveUserParam.getUserType() ? Constants.USER_TYPE.ENTERPRISE : Constants.USER_TYPE.PERSONAL,
                    Constants.CONTRACT_NEEDVIDEO.NONE, true);


            InputStream is=new FileInputStream(new File(DEST));
            String doc=FileUtils.fileUpload(is);
            if (StringUtils.isEmpty(doc)){
                //异常失败记录
                AbnormalLog abnormalLog=new AbnormalLog();
                BeanUtils.copyProperties(abnormalLog, generateContractParam);
                abnormalLog.setResult("文件存储服务器已满！");
                abnormalLog.setState("0");
                abnormalLog.setTenant(JacksonUtil.toJson(tenant));
//                contractMapper.insertAbnormal(abnormalLog);
                logger.info("generateContractRealTime文件存储服务器已满！");

                try {
                    sendEmail(generateContractParam.getOrderId()+"生成合同上传文件存储服务器失败", "订单号："+generateContractParam.getOrderId());
                }catch (Exception e){
                    logger.error("generateContractRealTime正常失败记录发短信失败>>" + e.getMessage(), e);
                }
                remoteResult.setResultCode("1004");
                remoteResult.setResultMsg("生成合同上传文件存储服务器失败！");
                return remoteResult;
            }
            String docurl=pdfProperties.getAccessUrl()+doc;
            JSONObject jsonObject = getClient(sendUserParam.getMid(), sendUserParam.getPrivatekey())
                    .sjdsendcontractdocUpload(new ReceiveUser[]{ReceiveUser}, sendUser, new File(DEST));

            if (getCode(jsonObject).equals("100000")) {
                String signid= getcontent(jsonObject).getJSONArray("contlist").getJSONObject(0).getJSONObject("continfo").getString("signid");
                Contract contract=new Contract();
                contract.setContractId(contractID);
                contract.setOrderId(generateContractParam.getOrderId());
                contract.setDocId(signid);
                contract.setDocSurl(docurl);
                contract.setSendUserDevno(sendUserParam.getDevno());
                contract.setReceiveUserDevno(receiveUserParam.getDevno());
                contract.setReceiveUserId(generateContractParam.getReceiveUserID());
                contract.setSendUserId(generateContractParam.getSendUserID());
                contractMapper.insertContract(contract);

                //通知订单
                AuditStatusContractParam auditStatusContractParam=new AuditStatusContractParam();
                auditStatusContractParam.setAuditStatus(1);
                auditStatusContractParam.setOrderId(contract.getOrderId());
                auditStatusContractParam.setUrl(contract.getDocSurl());
//                logger.info("generateContractRealTime 生成合同通知订单参数》》" + JacksonUtil.toJson(auditStatusContractParam));
//                RemoteResult remoteResult1=orderMiddlewareService.updateAuditStatusByContract(tenant,auditStatusContractParam);
//                logger.info("generateContractRealTime 生成合同通知订单返回》》" + JacksonUtil.toJson(remoteResult1));
                remoteResult.setT(auditStatusContractParam);
                logger.info("generateContractRealTime返回>>一切正常！");
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("0000");
                remoteResult.setResultMsg("成功！");
                return remoteResult;

            }else {
                AbnormalLog abnormalLog=new AbnormalLog();
                try {
                    //正常失败记录
                    BeanUtils.copyProperties(abnormalLog, generateContractParam);
                    abnormalLog.setResult(jsonObject.toString());
                    abnormalLog.setState("2");
                    abnormalLog.setTenant(JacksonUtil.toJson(tenant));
//                    contractMapper.insertAbnormal(abnormalLog);
                    sendEmail(generateContractParam.getOrderId()+"上上签生成合同返回失败","异常提示："+jsonObject.toString());
                } catch (Exception e1) {
                    logger.error("generateContractRealTime正常失败记录失败>>" + e1.getMessage(),e1);
                    e1.printStackTrace();
                }
                logger.info("generateContractRealTime 上上签生成合同返回失败》》"+jsonObject.toString());
                remoteResult.setResultCode("1005");
                remoteResult.setResultMsg("上上签生成合同返回失败！"+jsonObject.toString());
                return remoteResult;
            }
        }catch (Exception e){
            logger.error("generateContractRealTime异常>>" + e.getMessage(), e);
            AbnormalLog abnormalLog=new AbnormalLog();
            try {
                //异常失败记录
                BeanUtils.copyProperties(abnormalLog, generateContractParam);
                abnormalLog.setResult(e.getMessage());
                abnormalLog.setTenant(JacksonUtil.toJson(tenant));
                abnormalLog.setState("0");
//                contractMapper.insertAbnormal(abnormalLog);
                sendEmail(generateContractParam.getOrderId() + "生成合同报错啦", "异常提示：" + e.getMessage());
                remoteResult.setResultCode("9999");
                remoteResult.setResultMsg("失败！");
                logger.error("generateContractRealTime异常" + e.getMessage(), e);
                return remoteResult;
            } catch (Exception e1) {
                logger.error("generateContractRealTime重试记录失败>>" + e1.getMessage(), e1);
                remoteResult.setResultCode("9999");
                remoteResult.setResultMsg("失败！");
                return remoteResult;
            }
        }
//        return remoteResult;
    }

    /**
     * 惠商合同生成
     * @param generateContractParam
     * @param tenant
     */
    private void generateContractStart(GenerateContractParam generateContractParam,Tenant tenant){
        logger.info("generateContract请求>>" + JacksonUtil.toJson(generateContractParam));

        try {
            if(ParamBeanUtils.checkFieldValueNull(generateContractParam)) {
                logger.info("generateContract 》》参数不能为空！");
                return;
            }
            Contract contractIN=contractMapper.selectContract(generateContractParam.getOrderId());
            if(contractIN!=null) {

                //通知订单
                AuditStatusContractParam auditStatusContractParam=new AuditStatusContractParam();
                auditStatusContractParam.setAuditStatus(1);
                auditStatusContractParam.setOrderId(contractIN.getOrderId());
                auditStatusContractParam.setUrl(contractIN.getDocSurl());
                logger.info("generateContract 生成合同通知订单参数》》" + JacksonUtil.toJson(auditStatusContractParam));
                RemoteResult remoteResult1=orderMiddlewareService.updateAuditStatusByContract(tenant,auditStatusContractParam);
                logger.info("generateContract 生成合同通知订单返回》》" + JacksonUtil.toJson(remoteResult1));
                return;
            }
            SendUserParam sendUserParam = getSendUserParam(generateContractParam.getSendUserID());
            ReceiveUserParam receiveUserParam = contractMapper.selectReceiveUser(generateContractParam.getReceiveUserID());
            if(sendUserParam == null){
                logger.info("generateContract 》》没有找到分销商！");
                return;
            }
            if(StringUtils.isEmpty(sendUserParam.getName())){
                logger.info("generateContract 》》没有找到分销商！");
                return;
            }
            if(receiveUserParam == null){
                logger.info("generateContract 》》没有找到经销商！");
                return;
            }
            if(StringUtils.isEmpty(receiveUserParam.getName())){
                logger.info("generateContract 》》没有找到经销商！");
                return;
            }
            URL url = new URL(pdfProperties.getHtmlUrl());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            InputStream inputStream = conn.getInputStream(); //通过输入流获得网站数据
            byte[] getData = readInputStream(inputStream); //获得网站的二进制数据
            String dataHtml = new String(getData, "UTF-8");

            RemoteResult<MongoOrderDetail> result=openOrderService.getMongoOrderDetail(tenant, generateContractParam.getOrderId());
            logger.info("generateContract 》》订单接口信息！"+JacksonUtil.toJson(result));
            if(result.getT()==null){
                logger.info("generateContract 》》没有找到订单信息！");
                return;
            }
            SimpleDateFormat formath=new SimpleDateFormat("yyyyMMddHHmmss");
            String contractID="HS"+formath.format(new Date())+"H"+generateContractParam.getOrderId();
            dataHtml = dataHtml.replace("contractID",contractID);//合同编号
            dataHtml = dataHtml.replace("sendUserNmae", generateContractParam.getSendUserName());
            dataHtml = dataHtml.replace("receiveUserName", generateContractParam.getReceiveUserName());
            dataHtml = dataHtml.replace("money", generateContractParam.getMoney());
            dataHtml = dataHtml.replace("costItem", result.getT().getCostItem().getAmount().doubleValue()+result.getT().getTotalTax().getAmount().doubleValue()+"");//订单金额
            dataHtml = dataHtml.replace("products", getTable(result.getT()));

            String DEST = pdfProperties.getPdfPath() + "contract.pdf";

            String HTML = pdfProperties.getHtmlPath() + "contract.html";
            File fileHTML = new File(HTML);
            FileWriter fileWritter = new FileWriter(fileHTML);
            BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
            bufferWritter.write(dataHtml);
            bufferWritter.close();
            String cmdret = CmdUtil.callCmd("wkhtmltopdf --margin-bottom 0 --margin-top 0 " + HTML + " " + DEST);
            logger.info("downloadContractFoId----" + "wkhtmltopdf " + HTML + " " + DEST + ">>命令返回：" + cmdret);


            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

            SendUser sendUser = new SendUser(sendUserParam.getEmail(), sendUserParam.getName(), sendUserParam.getMobile(),
                    99, true, Constants.USER_TYPE.ENTERPRISE.value() == sendUserParam.getUsertype() ? Constants.USER_TYPE.ENTERPRISE : Constants.USER_TYPE.PERSONAL,
                    true, sendUserParam.getName() + "-" + receiveUserParam.getName() + "合同" + format.format(new Date()), "");

            ReceiveUser ReceiveUser = new ReceiveUser(receiveUserParam.getEmail(), receiveUserParam.getName(), receiveUserParam.getMobile(),
                    Constants.USER_TYPE.ENTERPRISE.value() == receiveUserParam.getUserType() ? Constants.USER_TYPE.ENTERPRISE : Constants.USER_TYPE.PERSONAL,
                    Constants.CONTRACT_NEEDVIDEO.NONE, true);


            InputStream is=new FileInputStream(new File(DEST));
            String doc=FileUtils.fileUpload(is);
            if (StringUtils.isEmpty(doc)){
                //异常失败记录
                AbnormalLog abnormalLog=new AbnormalLog();
                BeanUtils.copyProperties(abnormalLog, generateContractParam);
                abnormalLog.setResult("文件存储服务器已满！");
                abnormalLog.setState("0");
                abnormalLog.setTenant(JacksonUtil.toJson(tenant));
                contractMapper.insertAbnormal(abnormalLog);
                logger.info("generateContract文件存储服务器已满！");

                try {
                    sendEmail(generateContractParam.getOrderId()+"生成合同上传文件存储服务器失败", "订单号："+generateContractParam.getOrderId());
                }catch (Exception e){
                    logger.error("generateContract正常失败记录发短信失败>>" + e.getMessage(), e);
                }
                return;
            }
            String docurl=pdfProperties.getAccessUrl()+doc;
            JSONObject jsonObject = getClient(sendUserParam.getMid(), sendUserParam.getPrivatekey())
                    .sjdsendcontractdocUpload(new ReceiveUser[]{ReceiveUser}, sendUser, new File(DEST));

            if (getCode(jsonObject).equals("100000")) {
                String signid= getcontent(jsonObject).getJSONArray("contlist").getJSONObject(0).getJSONObject("continfo").getString("signid");
                Contract contract=new Contract();
                contract.setContractId(contractID);
                contract.setOrderId(generateContractParam.getOrderId());
                contract.setDocId(signid);
                contract.setDocSurl(docurl);
                contract.setSendUserDevno(sendUserParam.getDevno());
                contract.setReceiveUserDevno(receiveUserParam.getDevno());
                contract.setReceiveUserId(generateContractParam.getReceiveUserID());
                contract.setSendUserId(generateContractParam.getSendUserID());
                contractMapper.insertContract(contract);

                //通知订单
                AuditStatusContractParam auditStatusContractParam=new AuditStatusContractParam();
                auditStatusContractParam.setAuditStatus(1);
                auditStatusContractParam.setOrderId(contract.getOrderId());
                auditStatusContractParam.setUrl(contract.getDocSurl());
                logger.info("generateContract 生成合同通知订单参数》》" + JacksonUtil.toJson(auditStatusContractParam));
                RemoteResult remoteResult1=orderMiddlewareService.updateAuditStatusByContract(tenant,auditStatusContractParam);
                logger.info("generateContract 生成合同通知订单返回》》" + JacksonUtil.toJson(remoteResult1));

                logger.info("generateContract返回>>一切正常！");

            }else {
                AbnormalLog abnormalLog=new AbnormalLog();
                try {
                    //正常失败记录
                    BeanUtils.copyProperties(abnormalLog, generateContractParam);
                    abnormalLog.setResult(jsonObject.toString());
                    abnormalLog.setState("2");
                    abnormalLog.setTenant(JacksonUtil.toJson(tenant));
                    contractMapper.insertAbnormal(abnormalLog);
                    sendEmail(generateContractParam.getOrderId()+"上上签生成合同返回失败","异常提示："+jsonObject.toString());
                } catch (Exception e1) {
                    logger.error("generateContract正常失败记录失败>>" + e1.getMessage(),e1);
                    e1.printStackTrace();
                }
            }
        }catch (Exception e){
            logger.error("generateContract异常>>" + e.getMessage(), e);
            AbnormalLog abnormalLog=new AbnormalLog();
            try {
                //异常失败记录
                BeanUtils.copyProperties(abnormalLog, generateContractParam);
                abnormalLog.setResult(e.getMessage());
                abnormalLog.setTenant(JacksonUtil.toJson(tenant));
                abnormalLog.setState("0");
                contractMapper.insertAbnormal(abnormalLog);
                sendEmail(generateContractParam.getOrderId()+"生成合同报错啦","异常提示："+e.getMessage());
            } catch (Exception e1) {
                logger.error("generateContract重试记录失败>>" + e1.getMessage(), e1);
                e1.printStackTrace();
            }
            e.printStackTrace();
        }

    }

    private String getTable(MongoOrderDetail detail){
        StringBuilder retTable=new StringBuilder("");
        //总金额result.getT().getCostItem();
        List<Product> products=detail.getProducts();
        if (products!=null&&products.size()>0){
            retTable.append("<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\">");
            retTable.append("<tr><td>序号</td><td>产品名称</td><td>单位</td><td>数量</td><td>单价（人民币）</td><td>总价（人民币）</td></tr>");
            for (int i=0;i<products.size();i++){
                retTable.append("<tr>");
                retTable.append("<td>");
                retTable.append(i+1);
                retTable.append("</td>");
                retTable.append("<td>");
                retTable.append(products.get(i).getProductName());
                retTable.append("</td>");
                retTable.append("<td>");
                retTable.append(products.get(i).getUnit());
                retTable.append("</td>");
                retTable.append("<td>");
                retTable.append(products.get(i).getProductNumber());
                retTable.append("</td>");
                retTable.append("<td>");
                retTable.append(products.get(i).getProductPay().getAmount().doubleValue());
                retTable.append("</td>");
                retTable.append("<td>");
                retTable.append(products.get(i).getProductPay().getAmount().doubleValue()*Integer.parseInt(products.get(i).getProductNumber()));
                retTable.append("</td>");
                retTable.append("</tr>");
            }
            retTable.append("</table>");
        }
        return retTable.toString();
    }
    @Override
    public RemoteResult<String> createReceiveUserAndcertApply(ReceiveUserParam receiveUserParam) {
        logger.info("createReceiveUserAndcertApply请求>>"+ JacksonUtil.toJson(receiveUserParam));
        RemoteResult remoteResult=new RemoteResult(false);
        if(ParamBeanUtils.checkFieldValueNull(receiveUserParam)) {
            remoteResult.setResultMsg("参数不能为空！");
            return remoteResult;
        }
        try {
            JSONObject result = getClient(receiveUserParam.getMid(), receiveUserParam.getPrivatekey())
                    .regUser(Constants.USER_TYPE.ENTERPRISE.value() == receiveUserParam.getUserType() ? Constants.USER_TYPE.ENTERPRISE : Constants.USER_TYPE.PERSONAL,
                            receiveUserParam.getEmail(),
                            receiveUserParam.getMobile(),
                            receiveUserParam.getName());
            logger.info("createReceiveUserAndcertApply:result>>" + result.toString());

            if (getCode(result).equals("100000")) {
                Constants.CA_TYPE caType = Constants.CA_TYPE.ZJCA;//个人类型的账号申请CFCA,企业类型的账号申请ZJCA
                JSONObject certificateApplyResult = getClient(receiveUserParam.getMid(), receiveUserParam.getPrivatekey())
                        .certificateApply(caType, receiveUserParam.getName(),
                                "123456", receiveUserParam.getLinkMan(), receiveUserParam.getMobile(),
                                receiveUserParam.getEmail(), receiveUserParam.getAddress(), receiveUserParam.getProvince(),
                                receiveUserParam.getCity(), receiveUserParam.getLinkIdCode(), receiveUserParam.getIcCode(),
                                receiveUserParam.getOrgCode(), receiveUserParam.getTaxCode());

                logger.info("createReceiveUserAndcertApply:certificateApplyResult>>" + certificateApplyResult.toString());

                if (certificateApplyResult.get("isResult").toString().equals("true")) {
                    ReceiveUserParam receiveUser = contractMapper.selectReceiveUser(receiveUserParam.getId());
                    int count=contractMapper.checkReceiveUser(receiveUserParam.getMobile());
                    if (receiveUser!=null&&count>0) {
                        remoteResult.setSuccess(true);
                    }else if(count>0&&receiveUser==null){
                        remoteResult.setResultMsg("此手机号已被其他经销商注册!");
                    }else if(count==0&&receiveUser==null){
                        contractMapper.insertReceiveUser(receiveUserParam);
                        remoteResult.setSuccess(true);
                    }else {
                        remoteResult.setResultMsg("此次注册的经销商与上次手机号不符!");
                    }
                }
                remoteResult.setT(result.toString() + certificateApplyResult.toString());
            } else {
                remoteResult.setT(result.toString());
            }
        } catch (Exception e) {
            logger.error("createReceiveUserAndcertApply异常>>"+e.getMessage(),e);
            remoteResult.setT(e.getMessage());
            e.printStackTrace();
        }
        logger.info("createReceiveUserAndcertApply返回>>" + JacksonUtil.toJson(remoteResult));
        return remoteResult;
    }

    @Override
    public RemoteResult<String> createSendUserAndcertApply(SendUserParam sendUserParam) {
        logger.info("createSendUserAndcertApply请求>>"+ JacksonUtil.toJson(sendUserParam));
        RemoteResult remoteResult=new RemoteResult(false);
        try {
            contractMapper.insertSendUser(sendUserParam);
            remoteResult.setSuccess(true);
        } catch (Exception e) {
            logger.error("createSendUserAndcertApply异常>>"+e.getMessage(),e);
            remoteResult.setT(e.getMessage());
            e.printStackTrace();
        }
        logger.info("createSendUserAndcertApply返回>>"+ JacksonUtil.toJson(remoteResult));
        return remoteResult;
    }

    @Override
    public RemoteResult<String> autoSignBymixed(AutoSignBymixedParam autoSignBymixedParam,Tenant tenant) {
        logger.info("autoSignBymixed请求>>" + JacksonUtil.toJson(autoSignBymixedParam));
        RemoteResult remoteResult=new RemoteResult(false);
        if(StringUtils.isEmpty(autoSignBymixedParam.getOrderId())) {
            remoteResult.setResultMsg("参数不能为空！");
            remoteResult.setResultCode(ErrorCode.PARAMETER_ERROR);
            return remoteResult;
        }
        try {
            Contract contract=contractMapper.selectContract(autoSignBymixedParam.getOrderId());
            if(!StringUtils.isEmpty(contract.getDocQurl())){
                //通知订单
                AuditStatusContractParam auditStatusContractParam=new AuditStatusContractParam();
                auditStatusContractParam.setAuditStatus(5);
                auditStatusContractParam.setOrderId(contract.getOrderId());
                auditStatusContractParam.setUrl(contract.getDocQurl());
                logger.info("autoSignBymixed 签署合同通知订单参数》》" + JacksonUtil.toJson(auditStatusContractParam));
                RemoteResult remoteResult1=orderMiddlewareService.updateAuditStatusByContract(tenant,auditStatusContractParam);
                logger.info("autoSignBymixed 签署合同通知订单返回》》" + JacksonUtil.toJson(remoteResult1));
                remoteResult.setSuccess(true);
                remoteResult.setResultCode(ErrorCode.SUCCESSFUL);
                remoteResult.setT(contract.getDocQurl());
                return remoteResult;
            }

            SendUserParam sendUserParam= getSendUserParam(contract.getSendUserId());
            String sCoordinatelist="[{\"pagenum\": \"1\",\"signx\": \""+pdfProperties.getSendUserX()+"\",\"signy\": \""+pdfProperties.getSendUserY()+"\"}]";
            String rCoordinatelist="[{\"pagenum\": \"1\",\"signx\": \""+pdfProperties.getReceiveUserX()+"\",\"signy\": \""+pdfProperties.getReceiveUserY()+"\"}]";
            BestSignSDK bestSignSDK =getClient(sendUserParam.getMid(), sendUserParam.getPrivatekey());

            int scode=0;
            int rcode=0;
            JSONObject signResult= null;
            try {
                logger.info("<=======sendUserDevno:{},receiveUserDevno:{}==========>", contract.getSendUserDevno(),contract.getReceiveUserDevno());
                signResult = bestSignSDK.AutoSignFopp(contract.getSendUserDevno(), contract.getDocId(), sCoordinatelist, "0", "", "");
            } catch (BizException e) {
                if(e.getCode()==120122){
                    scode=120122;
                    logger.info("autoSignBymixed 签署合同分销商重复签署》》" + e.getCode());
                }else {
                    remoteResult.setResultMsg("签署合同分销商失败上上签返回code："+e.getCode());
                    logger.info("autoSignBymixed 签署合同分销商失败上上签返回code：" + e.getCode());
                    remoteResult.setResultCode(ErrorCode.SSQ_FAILURE);
                    return remoteResult;
                }
                remoteResult.setResultCode(ErrorCode.SSQ_FAILURE);
                e.printStackTrace();
            }

            JSONObject signResult2 = null;
            try {
                signResult2 = bestSignSDK.AutoSignFopp(contract.getReceiveUserDevno(),contract.getDocId(), rCoordinatelist, "1", "", "");
            }catch (BizException e) {
                if(e.getCode()==120122){
                    rcode=120122;
                    logger.info("autoSignBymixed 签署合同经销商重复签署》》" + e.getCode());
                }else{
                    remoteResult.setResultMsg("签署合同经销商失败返回code:"+e.getCode());
                    logger.info("autoSignBymixed 签署合同经销商失败》》" + e.getCode());
                    remoteResult.setResultCode(ErrorCode.SSQ_FAILURE);
                    return remoteResult;
                }
                remoteResult.setResultCode(ErrorCode.SSQ_FAILURE);
                e.printStackTrace();
            }

            String docurl="";
            if((getCode(signResult).equals("100000")&&getCode(signResult2).equals("100000")) ||
                    (scode==120122&&rcode==120122)||
                    (getCode(signResult).equals("100000")&&rcode==120122)||
                    (getCode(signResult2).equals("100000")&&scode==120122)){
                byte[] pdf=bestSignSDK.contractDownloadMobile(contract.getDocId());
                docurl=pdfProperties.getAccessUrl()+FileUtils.fileUpload(pdf);
                contractMapper.updateContractUrl(contract.getDocId(), docurl);

                //通知订单
                AuditStatusContractParam auditStatusContractParam=new AuditStatusContractParam();
                auditStatusContractParam.setAuditStatus(5);
                auditStatusContractParam.setOrderId(contract.getOrderId());
                auditStatusContractParam.setUrl(docurl);
                logger.info("autoSignBymixed 签署合同通知订单参数》》" + JacksonUtil.toJson(auditStatusContractParam));
                RemoteResult remoteResult1=orderMiddlewareService.updateAuditStatusByContract(tenant,auditStatusContractParam);
                logger.info("autoSignBymixed 签署合同通知订单返回》》" + JacksonUtil.toJson(remoteResult1));
                remoteResult.setResultCode(ErrorCode.SUCCESSFUL);
                remoteResult.setSuccess(true);
                remoteResult.setT(docurl);
            }
            logger.info("autoSignBymixed合同返回信息>>" + (signResult==null?"(----)":signResult.toString()) + (signResult2==null?"(----)":signResult2.toString()));
        } catch (Exception e) {
            logger.error("autoSignBymixed异常>>" + e.getMessage(),e);
            remoteResult.setResultCode(ErrorCode.FAILURE);
            e.printStackTrace();
        }
        logger.info("autoSignBymixed返回>>"+ JacksonUtil.toJson(remoteResult));

        return remoteResult;
    }

    @Override
    public RemoteResult<Contract> getContract(String orderId) {
        logger.info("getContract请求>>" + orderId);
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            Contract contract=contractMapper.selectContract(orderId);
            remoteResult.setSuccess(true);
            remoteResult.setT(contract);
        } catch (Exception e) {
            logger.error("getContract异常>>" + e.getMessage(),e);
            e.printStackTrace();
        }
        logger.info("getContract返回>>"+ JacksonUtil.toJson(remoteResult));
        return remoteResult;
    }


    public BestSignSDK getClient(String mid,String privatekey){
        BestSignSDK client= null;
        try {
            client = BestSignSDK.getInstance(mid, privatekey, signProperties.getHost());
            client.setLogDir(System.getProperty("user.dir"));
            client.setDebugLevel(cn.bestsign.sdk.integration.Logger.DEBUG_LEVEL.INFO);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return client;
    }

    public static byte[] readInputStream(InputStream inputStream) throws IOException {
        byte[] buffer = new byte[1024];
        int len = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        while ((len = inputStream.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }

        bos.close();
        return bos.toByteArray();
    }

    public Map<String, Object> parseJSON2Map(String jsonStr){
        ListOrderedMap map = new ListOrderedMap();
        //最外层解析
        JSONObject json = JSONObject.parseObject(jsonStr);
        for(Object k : json.keySet()){
            Object v = json.get(k);
            //如果内层还是数组的话，继续解析
            if(v instanceof JSONArray){
                List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
                Iterator<Object> it = ((JSONArray)v).iterator();
                while(it.hasNext()){
                    JSONObject json2 = (JSONObject)it.next();
                    list.add(parseJSON2Map(json2.toString()));
                }
                map.put(k.toString(), list);
            } else {
                map.put(k.toString(), v);
            }
        }
        return map;
    }

    private String getCode(JSONObject jsonObject){
        try {
            return jsonObject.getJSONObject("response").getJSONObject("info").getString("code");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    private JSONObject getcontent(JSONObject jsonObject){
        try {
            return jsonObject.getJSONObject("response").getJSONObject("content");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private SendUserParam getSendUserParam(String sendId){
        SendUserParam sendUserParam=new SendUserParam();
        Map<String, Object> lenovo_param_json = new HashMap<String, Object>();
        lenovo_param_json.put("jxsNum", sendId);

        Response response = null;
        try {
            response = JavaSDKClient.proxy(signProperties.getInterfaceUrl(), signProperties.getAppKey(), signProperties.getAppSecret(), signProperties.getMethod(), lenovo_param_json, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("getSendUserParam>>status============" + response.getStatus());
        logger.info("getSendUserParam>>body============" + response.getBody().toString());

        JSONObject jsonObject=JSONObject.parseObject(response.getBody().toString());
        JSONObject data=jsonObject.getJSONObject("result").getJSONObject("lenovo_cerp_getfxsssq_hs_response");
        if(data!=null) {
            sendUserParam.setId(data.getString("fxsNum"));
            sendUserParam.setName(data.getString("fxsName"));
            sendUserParam.setMid(data.getString("ssqMid"));
            sendUserParam.setPrivatekey(data.getString("ssqKey"));
            sendUserParam.setEmail(data.getString("ssqAccount"));
            sendUserParam.setMobile(data.getString("fxsPhone"));
            sendUserParam.setUsertype(2);
        }
        return sendUserParam;
    }

    public void sendEmail(String title,String content){
        String url=signProperties.getEmailUrl();
        try {
            url=url+"?title="+ URLEncoder.encode(title, "utf-8")
            +"&content=" + URLEncoder.encode(content,"utf-8")
                    + "&toAddress=" + signProperties.getEmails() ;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String ret=HttpClientUtil.getStr(url);
        logger.info("sendEmail返回>>" + ret);
    }

    public static void main(String[] args) {

    }
}
