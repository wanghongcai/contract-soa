package com.lenovo.contract.dao;

import com.lenovo.contract.domain.AbnormalLog;
import com.lenovo.contract.domain.Contract;
import com.lenovo.contract.domain.param.ReceiveUserParam;
import com.lenovo.contract.domain.param.SendUserParam;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;
import java.util.List;

public interface ContractMapper {
    int insertSendUser(SendUserParam sendUserParam);
    SendUserParam selectSendUser(String fid);

    int insertReceiveUser(ReceiveUserParam receiveUserParam);
    ReceiveUserParam selectReceiveUser(String jid);

    int checkReceiveUser(String mobile);

    int insertContract(Contract contract);

    Contract selectContract(String orderId);

    int updateContractUrl(@Param("docid")String docid,@Param("url")String url);

    int insertAbnormal(AbnormalLog abnormalLog);

    ArrayList<AbnormalLog> getAbnormalLog();

    int updateAbnormalLog(String orderId);

}